<?php 



$conn = mysqli_connect("localhost","root","","shopping");

 if(!$conn)
 {
    echo "Connection not  Successfull";

 }

 

?>